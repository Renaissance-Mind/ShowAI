# MCP 连接配置

本文件用于宿主接入、连接错误或切换内容库。普通 Agent 文档操作始终使用已连接的 MCP 工具，不先执行 CLI 文档命令。

先检查当前连接的工具和授权状态。安装、重连和内容库绑定方式见随包的[连接向导](connect-mcp.md)。

工具未出现在当前会话中，可能需要宿主刷新连接。先核对安装和连接状态；需要重启宿主时协调用户，不自行退出宿主。没有 MCP 连接时说明缺少的入口，不以 CLI 创作或独立文件替代正式项目操作。

<!-- showai-only:local -->

## 本机插件

本地插件的 MCP 配置启动 `mcp/launch.mjs`。启动器读取宿主指定的 `SHOWAI_HOME`，未指定时使用当前用户的 `~/.showai`，再读取该库的 `agent-runtime.json`。`SHOWAI_RUNTIME_CONFIG` 可显式指定配置文件，但其中 home 必须与选定库一致；出错时不搜索其他库。

启动器只用 CLI 做 runtime info 能力探测和启动 MCP；探测结果按运行时文件缓存在库的 `local/` 中。运行时必须声明 `capabilities.agentOperations.protocol=showai-mcp-v1`。缺少时需要更新并登记目标 ShowAI 软件；更新 Skill 不会更新软件。插件本身不包含文档编译运行时。

启动器在启动 MCP 之前失败时（缺少或无法读取 `agent-runtime.json`、内容库不一致、运行时过旧或无法启动），仍完成 MCP 握手，只提供一个 `showai_connection_problem` 工具。看到这个工具时调用它，把返回的错误码、原因和修复步骤用用户的语言转述，例如在 ShowAI「设置 → Agent 插件」点「修复登记」或「更新并启用」，再重启 Agent 会话或刷新宿主连接。返回内容中的路径已脱敏为 `~` 与 `<library>`，转述时保持脱敏，不要补全为本机完整路径。不要重试其他工具、换内容库或修改配置文件。ShowAI「设置 → Agent 插件」也会显示这次失败。

在 ShowAI「设置 → Agent 插件」检查当前登记的运行时、内容库和插件状态。安装、刷新会话和重新绑定内容库请按[连接向导](connect-mcp.md)执行。

源码方式的插件 launcher 使用系统 Node.js，需要 Node.js 22.12+ 和已登记的 ShowAI 软件。

可由宿主设置：

| 配置                    | 作用                                                       |
| ----------------------- | ---------------------------------------------------------- |
| SHOWAI_HOME             | 明确的本机内容库                                           |
| SHOWAI_RUNTIME_CONFIG   | 该库对应的运行入口配置                                     |
| SHOWAI_PROJECT_ID       | 可选，锁定一个已存在的项目；省略则由工具显式选择项目       |
| SHOWAI_PRESENTATION_DIR | 可选，宿主允许的绝对展示输出目录；否则由运行时分配预览目录 |

项目绑定连接还可设置 `SHOWAI_TEMPLATES`（格式 `ID[@VERSION],ID`）作为该会话的默认模板选择，必须同时设置 `SHOWAI_PROJECT_ID`；内容库连接在每次任务用 template_context 显式选择模板。

对话预览默认携带压缩的本地阅读器；超出聊天预算时，才回退到已发布的 CDN 阅读器。紧凑片段、在线页和显式 `reader:"cdn"` 导出依次从 ShowAI 阅读器源（reader.showai.renaissancemind.ai）、jsDelivr、unpkg 加载阅读器。宿主可设 `SHOWAI_READER_CDN=off` 禁用 CDN 回退与在线版，或设为逗号分隔的镜像基础地址（支持 `{name}`、`{version}` 占位）。插件安装不会更新独立的软件运行时，也不能预热对话宿主的浏览器缓存；核对实际运行时和生成的交付物，详见[宿主显示](host-display.md)。

不修改系统 HOME，也不直接编辑库里的正式文件。运行期间库位置保持固定；要换库，宿主停止并重连另一个配置，再查 capabilities/context。

## 连接中断或没有工具

先辨别连接类型：通过 HTTPS 地址连接的客户端应按[连接向导](connect-mcp.md)检查 App、隧道地址与授权状态，不检查本机 launcher 或要求安装 Node.js。以下步骤只适用于本机 stdio 插件。

宿主报告 ShowAI 连接已关闭（例如 `Connection closed`），或会话中没有任何 ShowAI 工具（连 `showai_connection_problem` 也没有）时，说明 MCP 进程没有启动或已经退出。启动时就失败的操作没有写入 ShowAI；保存进行中连接断开时，结果不确定，恢复连接后先 `page_read` 核对内容是否已保存，再决定是否重试。

1. 告诉用户连接失败、哪一步没有完成，并把要保存的内容留在对话中，便于重试。
2. 请用户打开 ShowAI「设置 → Agent 插件」：查看「当前登记的运行时」、各插件连接的内容库和「最近一次连接失败」。「修复登记」修复内容库里登记的运行时，任何安装方式都适用；「更新并启用」重新安装 App 自带的插件，适用于从 App 安装的插件。源码或插件市场安装时，先修复登记，仍失败再按第 4 步检查 Node.js，或在宿主中停用原插件后改从 App 安装。
3. 修复后需要重启 Agent 会话或刷新宿主连接，才会重新启动 MCP；协调用户完成，不自行退出宿主。
4. 判断安装方式：App 安装的 MCP 配置 以 ShowAI App 的可执行文件启动 launcher；`command` 为 `node` 时是源码或插件市场安装，需要 Node.js 22.12+，缺少或版本过旧也会导致连接关闭。
5. 具体原因记录在宿主的 MCP 日志（launcher 的 stderr）中；仍无法解决时，请用户在 ShowAI「设置 → 关于与反馈」报告问题（这一入口不依赖 Agent 连接）。

<!-- /showai-only -->

## 错误码与下一步

工具错误都带 `code`、`message`，常见错误还带 `nextStep`（下一步做什么）和 `userMessage`（可直接转述的一句话）。先按 `nextStep` 处理：

| 错误码                              | 含义                                             | Agent 怎么做                                                                                                                                                                               |
| ----------------------------------- | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| CONFLICT                            | 读取后内容已变化，没有覆盖                       | 重新读取，按 [保存、冲突与页面差异](editing.md) 比较期间的改动，保留他人的修改，再用新的 baseHash/baseRevision 提交；不重发原请求                                                                                                            |
| NOT_FOUND                           | 内容库中没有这个项目或页面                       | 列出现有内容，用返回的 ID 重试                                                                                                                                                             |
| INVALID_DATA                        | 请求的数据不符合格式或组件参数，没有保存任何内容 | 按 `message` 和 `details` 指出的位置修正自己的输入（组件参数用 `catalog_describe` 的 parameters 视图核对），重新读取后再提交一次；数据来自页面原有内容而无法修正时，作为无法恢复的失败处理 |
| INVALID_ARGUMENTS                   | 参数不符合这个工具当前的 inputSchema，没有执行   | 按 `unexpected`、`issues`、`expected`（动作工具另有 `actions`）改成当前写法再调用；工具形状的近期变化见 [协议变化](formats/migrations.json)                                                      |
| UNKNOWN_TOOL                        | 连接上没有这个工具名                             | 改用 `similar` 或 migrations 指南中的当前工具；只用这个连接列出的工具                                                                                                                      |
| INVALID_PATH                        | 路径不可用                                       | 改用本机绝对路径或 ShowAI 返回的 ID                                                                                                                                                        |
| LOCKED                              | 内容库正被其他操作占用                           | 等几秒后重试同一调用一次                                                                                                                                                                   |
| SNAPSHOT_EXPIRED / MISSING_BASELINE | 之前的读取结果或比较基线已失效                   | 重新读取后继续；写共享数据时返回的 MISSING_BASELINE 带 `details.datasetBases`，说明要传哪个共享数据的读取 hash，见 [共享数据](shared-data.md#读写)                                         |
| SOURCE_UNAVAILABLE                  | 共享数据的外部文件或在线数据现在读不到，或处理脚本还没有成功的结果 | 请用户恢复该文件或检查网址；本机读到过的值以 stale 返回，只能查看不能写入，见 [共享数据](shared-data.md#外部文件中的数据)；处理脚本按 `details.warnings` 修正，见 [处理脚本](shared-data.md#处理脚本) |
| READ_ONLY                           | 数据只读（在线数据、xlsx 文件、处理脚本的结果），没有改动 | 请用户在数据源中修改；用户要在 ShowAI 中编辑时，用 `dataset_write` 的 link `path:null` 复制进内容库                                                                                          |
| IN_USE                              | 组件或模板版本仍被页面、模板或发布使用，没有删除 | 把 `details.uses` 告诉用户；经同意后把这些块换到别的版本（component.ref.set）或移除，再删除 |
| CONFIRMATION_REQUIRED               | 需要用户先做决定                                 | 按 `details` 询问用户，再带上决定重试                                                                                                                                                      |
| ERROR 或其他                        | 未归类的失败                                     | 按下一节处理                                                                                                                                                                               |

修正输入后的请求是新的请求，使用新的 `operationId`；只有原样重试同一请求时才沿用原来的 `operationId`。同一错误按 `nextStep` 处理一次后仍出现，也按下一节处理。

工具名称和参数会随版本调整。按旧写法发出的近期调用（例如 `dataset_create`、不带 `action` 的 `dataset_read`）仍会执行，回执带 `migration`：`from` 是旧写法，`use` 是对应的当前工具与参数，`changes` 说明改了什么；之后改用 `use` 的写法。以连接实际暴露的 inputSchema 为准，不以记忆或旧笔记为准。

## 组件显示异常

用户说页面里的组件报错或显示不出来时，ShowAI 会在该位置显示组件状态卡片：「运行出错」「参数不符」或「缺少组件」，并提供「让 Agent 修复」「报告问题」等操作。

1. 确认是哪个页面、哪个组件；用户没有提供引用时先询问。
2. 用 `page_read`（必要时 `view:"html"` 或 `"image"`）读取页面，查看 warnings 中的组件状态，并记录组件引用（id、version、integrity）。
3. 用 `catalog_describe` 读取组件，按返回的 `scope` 判断来源：`builtin` 是 ShowAI 内置组件；`project` 是项目自有的自定义组件，按 [create-component](../../create-component/SKILL.md) 修复或重建；`global` 或 `published` 来自共享目录或发布源，修复需要它的维护者，可以先在本项目 fork 一份再修改。参数不符时按 parameters 视图修正页面数据。
4. 「缺少组件」表示页面引用的组件不在当前内容库：先用 `catalog_list` / `public_catalog_list` 查找同 id 的组件并导入或改用可用版本；找不到时按页面保留的数据用 create-component 重建兼容组件。
5. 内置组件出错属于 ShowAI 本身的问题：请用户在组件卡片或「设置 → 关于与反馈」中「报告问题」，诊断信息会自动附带。用户请你代办时，不代替提交，但可以整理一段问题说明交给用户粘贴：页面标题、组件 id 与版本、卡片状态（运行出错 / 参数不符 / 缺少组件）、错误原文和复现步骤，不包含本机路径、Token 或页面正文。

绑定共享数据的块显示旧数据或没有数据时，`page_read` 的 `bindings[]` 带 `status`（stale、empty）和 `warnings`，按 [共享数据](shared-data.md#外部文件中的数据) 的读取状态处理；warning 为 TRANSFORM_FAILED 或 OUTPUT_INVALID 时修改处理脚本，见 [处理脚本](shared-data.md#处理脚本)。

## 无法恢复的失败与反馈

工具返回 CONFLICT、NOT_FOUND、LOCKED 等可恢复错误时，按回执的 `nextStep` 处理，不当作故障上报。工具失败且无法恢复时（错误码为 ERROR、连接问题工具报告的启动失败，或按 `nextStep` 处理后仍失败），告诉用户哪一步失败，并给出错误码与 message；`userMessage` 是可直接转述的一句话。再提示用户在 ShowAI「设置 → 关于与反馈」点「复制诊断信息」或「报告问题」，或打开 `showai_capabilities` / `runtime info` 返回的 `support.reportUrl` 提交反馈，排障说明见 `support.docsUrl`。连接不可用、拿不到 `support` 时，「设置 → 关于与反馈」仍然可用。不要代替用户提交反馈，不要转述 Token、密钥或本机路径。

<!-- showai-only:universal -->

## 自定义 Agent / 服务器 runner

宿主也可直接启动已核实运行入口，追加 `mcp --home /ABSOLUTE_LIBRARY`；明确绑定项目时再追加 `--project PROJECT`。可选 `--presentation-directory /HOST_OUTPUT`。配置中的 command/args/env 用参数数组执行，不交给 shell eval。MCP 启动后，Agent 使用工具，不为每次读写拼接 shell 命令。

ShowAI 内置 Agent由宿主提供项目绑定 MCP；它安装的私有 Skill 副本不再同时加载插件的整个内容库启动器。模型 API 与文档 MCP 是两个连接。

<!-- /showai-only -->

<!-- showai-only:remote -->

## 远程

桌面 App 的「设置 → 远程 MCP」按“选择方式 → 建立连接 → 连接客户端”先从「局域网与私网」或「公网入口」选择连接方式。局域网只监听所选网卡，以 HTTP 和访问密钥连接；Tailscale 私网使用该设备的 HTTPS 地址，首次接入可在 ShowAI 直接批准设备，已有 OAuth 模式继续使用 Serve；公网访问使用 Cloudflare 临时/固定隧道或 Tailscale Funnel，并通过 HTTPS 与 OAuth 连接。此模式由 `showai_capabilities.projects.storage:"local"` 标识。新连接默认完整授权当前及以后新增的全部项目，支持读取、编辑、侧栏组织和 `project_create`。项目创建需要工具确实可用、完整内容库授权和 projects.create scope；保留返回的 project.id，后续操作显式使用它。同一次创建重试沿用同一个 operationId 和名称。受限连接仍只返回配置及授权同时允许的项目，不能从另一个连接照搬 ID。用户可以在「访问规则」中选择指定项目与只读权限；显式指定的访问规则保留；旧版没有 access 模式字段的配置采用全部内容库默认值，但原有受限 OAuth 授权会在启用前撤销，客户端必须重新配对确认新范围。将仅授权指定项目的客户端改为全部内容库授权时，设备和 OAuth 客户端需要重新获得批准。局域网客户端可以使用新的接入邀请或访问密钥。

在「设置 → 远程 MCP」复制当前连接的接入提示词，在宿主核对地址、传输方式和授权。设备批准后，用同一连接调用 `projects_list` 核对项目。

可信局域网的接入提示词包含一个十分钟内有效的一次性邀请。支持设置请求头和本地凭据存储的 Agent 按提示申请接入，用户在 ShowAI 批准。手动设置局域网客户端时，用户也可以在 App 中填写名称并创建访问密钥，再将其填入客户端的 Bearer Token 字段或 Authorization 请求头。密钥只显示一次，保存为摘要，90 天后到期，可单独撤销；模型不索取、读取或转述访问密钥。HTTP 只用于可信局域网，要求 HTTPS/OAuth 的客户端应选择 Tailscale 私网或公网方式。服务自检只证明本机访问，其他设备是否连通以真实调用为准。Tailscale 私网需要两端加入同一 tailnet 并启用 MagicDNS/HTTPS，不需要 Funnel。Serve 与 Funnel 使用未占用的 443、8443 或 10000，保留其他服务路由，断开只停止本次连接器。

从客户端检查已配置的远程地址与授权。使用已绑定的插件时，刷新原连接后再验证项目范围。

端口由程序自动绑定。自有域名步骤先保留本机监听，再让用户复制实际 HTTP 地址并配置 Cloudflare 路由，之后填写公网域名与隧道令牌；公网地址切换不释放监听端口。已有固定路由端口被其他程序占用时使用新的可用端口并引导更新路由，不结束其他程序。客户端使用流程生成的完整 /mcp 地址；局域网填写访问密钥，Tailscale 设备授权模式等待本机批准，OAuth 模式按客户端配置完成授权。详细操作见[用户教程](https://github.com/Renaissance-Mind/ShowAI/blob/main/docs/i18n/chatgpt.zh-CN.md)。

以下为配置了同步服务器的托管 HTTP 连接：宿主连接明确的 HTTP MCP 地址，完成所需授权。授权可限定项目，也可覆盖该服务器账号当前及以后有权限的所有项目。`projects_list` 每次读取服务器最新成员权限；账号授权会发现后续同步到服务器的项目。仅保存在本机且尚未同步的项目不在远程列表中：请用户在 ShowAI 应用的“设置 → 账号与同步”把项目同步到同一服务器账号，再重新调用 `projects_list`；仅授权单个项目的连接需重新授权为账号范围才能看到新项目。用户明确要求新项目时，且当前工具暴露 `project_create`、账号已授予 `projects.create`，使用该工具创建；保留返回的项目 ID 和 synchronization 回执，后续页面操作显式使用该 ID。创建超时或结果不明时，用同一个 operationId 和同一名称重试：已创建则返回原项目，不会重复创建；同一 operationId 换名称会被拒绝。不同请求使用不同 ID。受限授权或工具缺失时说明所缺权限，不绕过到本机创建。项目权限来自服务端当前成员身份。远程没有本机文件配置步骤，不能把用户电脑的 home 当作远程项目路径。远程网关部署与本机内容同步服务是不同模块。

GitHub／Google 登录由所选 ShowAI Server 的已配置登录方式提供。已有账号需先绑定对应身份。用户在第三方登录标签页完成验证后，该页显示一个 8 位完成码；用户回到 MCP 授权标签页填入完成码并继续，再确认项目或账号范围授权。完成码一次性、短期有效，由用户本人填写；模型不索取或转述。用户把完成码贴到对话中时不使用它，提醒其在授权页填写。模型不读取、索取或转发密码、登录轮询密钥和会话 Token。服务器未启用对应登录方式时报告实际错误，不把登录按钮可见当作登录已配置。

<!-- /showai-only -->

## 内容组织接口

先读 `showai_capabilities.management` 和当前工具参数。项目操作都显式传 `projectId`。只读查找不创建项目或文件夹；用户要求整理内容时才执行对应写操作。项目、文件夹、正式 Page 和侧栏分组是不同对象，分别使用各自接口。

| 目标                             | 接口与关键参数                                                                                                                                                                                                                 |
| -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 找项目与已归档项目               | `projects_list({includeArchived:true})`；默认不含已归档项目                                                                                                                                                                    |
| 项目名称、图标、置顶、归档与恢复 | `organization_update({projectId,action:"update_project",name?,icon?,pinned?,archived?})`；`archived:false` 恢复，归档保留内容。远程归档/恢复需要当前 admin 权限                                                                |
| 读取真实目录                     | `organization_read({projectId,action:"folders",includeArchived?})` 返回文件夹 ID、parentId、图标、置顶与排序偏好；`pages_list({projectId,includeArchived:false})` 取活动页面，省略 includeArchived 保留包含归档页的兼容行为    |
| 创建文件夹                       | `organization_update({projectId,action:"create_folder",name,icon?,parentId?})`；parentId 省略或 null 表示项目根目录                                                                                                            |
| 更新文件夹                       | `organization_update({projectId,action:"update_folder",folderId,name?,icon?,pinned?,archived?})`；归档隐藏后代，恢复保留原层级                                                                                                 |
| 删除、恢复、置顶 Page            | `organization_update({projectId,action:"update_page",pageId,archived?,pinned?,baseHash?,baseRevision?})`；`archived:true` 删除（进入已删除，可恢复），`archived:false` 恢复；不传 baseHash 时改当前版本，传了就同时传 baseRevision |
| 复制 Page                        | `organization_update({projectId,action:"duplicate_page",pageId,title?})`；新页面在同一文件夹，块 ID 全部重新生成，标题默认为“原标题 副本”                                                                                       |
| 查看可恢复的已删除内容           | `organization_read({projectId,action:"deleted"})` 列出已删除的项目、文件夹和页面；分别用 update_project、update_folder、update_page 的 `archived:false` 恢复                                                                     |
| 在文件夹中创建 Page/Board        | `page_create({projectId,parentId:文件夹ID,title,kind?})`；内容树中的 Page/Board 容器不充当目录                                                                                                                                 |
| 移动或排序条目                   | `organization_update({projectId,action:"move",kind:"page"或"folder",id,destinationProjectId?,parentId,relativeId?,placement?:"before"或"after",reorderOnly?,baseHash?,baseRevision?})`；parentId 是目标文件夹，null 表示根目录 |
| 设置目录排序                     | `organization_update({projectId,action:"sort",parentId,sortBy:"name"或"createdAt"或"updatedAt"或"manual"})`；只影响该目录直接子项                                                                                              |
| 读侧栏组织                       | `organization_read({projectId,action:"sidebar"})`；项目绑定连接不提供侧栏动作                                                                                                                                                  |
| 创建、改名或移除侧栏分组         | `organization_update({projectId,action:"create_group",name})`；`organization_update({projectId,action:"update_group",sidebarGroupId,name})`，name:null 移除分组并保留项目                                                      |
| 项目分组和手动顺序               | `organization_update({projectId,action:"move_project",sectionId,relativeProjectId?,placement?})`；sectionId 是 projects、pinned 或真实侧栏分组 ID                                                                              |

页面改名、图标和 parentId 修改使用 `page_apply` 的 `page.set`；删除、恢复和置顶也可以这样改，`update_page` 更直接，回执只含页面状态。字段里的 parentId 是目录 ID；块操作里的 parentId 是内容容器 ID。页面移动前读取完整当前源并传 baseHash/baseRevision；reorderOnly 只改同层顺序时无需页面内容版本。文件夹只支持项目内移动，不能移入自身或后代。新建或改动目录不会自动重组正文。

跨项目页面移动使用 `organization_update` 的 move，完整保留页面身份，并迁移其精确组件依赖。库连接允许本库项目之间移动；项目绑定连接只允许本项目。远程先从 `projects_list` 取得来源与目标 ID，两个项目都必须在当前授权内且可编辑；调用后检查 `synchronizations` 中的每个项目。远程依次同步目标与来源，中断时保留同步顺序并先恢复待办，不宣称跨两个项目具有服务器事务原子性。结果含错误或未同步状态时说明现状，不能创建另一份 Page 冒充移动成功。

文件夹、项目属性、目录排序和 Page 属于可同步的项目内容。侧栏分组、项目分组关系及库级手动顺序属于当前工作区偏好：本机保存在该库，远程保存在该授权连接的持久工作区，不会随项目同步到其他设备。远程回执的 `workspace.sidebarOrganizationSynchronized:false` 明确这一范围；项目自身的 pinned 属性仍会同步。不要把连接偏好描述为跨设备账号配置。

## 草稿接口

`draft_read({projectId,action:"list",clientId?,resourceId?,kind?})` 只读当前项目的保留草稿，kind 是 page、component 或 template。用返回的 id 调用 `draft_read({projectId,action:"read",draftId})`，读取内容、baseRevision、当前 generation 与作者信息。草稿独立于已保存 Page，也独立于外部文件冲突快照；恢复时先核对原稿、当前正式内容与用户意图。

`draft_write({projectId,action:"save",kind,clientId,resourceId,content,baseRevision?,baseContent?,title?,sequence?})` 保留未提交内容。clientId 是当前编辑客户端的稳定标识；同一客户端使用递增 sequence，同一 sequence 的不同内容会冲突。page 草稿的 baseContent 是准确的源 Page 基线，不使用截取片段或重新猜测的数据。保存草稿不等于保存正式内容。

明确放弃已阅读草稿时调用 `draft_remove({projectId,draftId,generation})`；只处理读取到的代次，发现新代次时报告冲突并保留。丢弃内容仍由本地恢复机制保留。page 草稿先通过正常 page_save/page_apply/合并路径保存，再用 `draft_write({projectId,action:"complete",draftId,generation,revision})` 完成；revision 来自实际保存结果，正式内容必须与该代草稿一致。组件和模板使用各自保存流程，成功后按用户意图移除已处理草稿。

草稿不会随项目同步。本机接口只访问当前库中的项目草稿；远程接口只访问该授权连接持久工作区的项目草稿，不能读取另一设备尚未上传的编辑草稿。远程回执的 `workspace.draftsSynchronized:false` 表示这一点。草稿接口不可访问其他项目或全局未归属草稿。

<!-- showai-only:remote -->

## 远程参数边界

远程 `page_export` 只声明 html、inline；整站 site 导出需要支持它的本机连接和用户指定的导出任务。远程 page_create/page_save 不接受 components 或 remoteComponents，先 `component_save` 编译可编辑源，再在页面中引用返回的精确版本和 integrity。本机仍可按实际参数传已编译组件或导入外部发布依赖。工具列表、参数和 `management` 能力以当前连接为准；插件更新不会自动更新正在运行的本机服务或远程部署。

<!-- /showai-only -->
