# Page 与 Board 的读取

使用已核实的 MCP 连接与 projectId。复用当前连接的 `showai_capabilities.boardReading`，参数见[页面读取格式](formats/reading.json)与实际工具 inputSchema。工具缺失表示运行时或宿主能力尚未更新，安装说明文件不会自动升级 App。

## Board 默认看图

理解 Board 时先调用 `board_read({projectId,pageId,boardId?})`。pageId 是保存资源 ID；资源根是 Board 时可省略 boardId，嵌入 Page 的 Board 用其稳定节点 ID。小画布返回清晰全图，大画布返回最长边 1200 像素的总览与重叠裁切图。窗口为 1600×1600、重叠 200 像素；scale 调整截图分辨率。图片以 MCP 图像附件返回，imageKey、attachmentIndex、pixelSize、bounds、imageToBoard 说明附件和画布坐标的对应关系。

保留 snapshotId。一次至多八张图；coverage.nextCursor 非空时用相同 snapshotId、mode:visual 和 cursor 继续。仅省略空窗口，coverage 保留完整网格、占用区间与空窗数；需要空窗时可显式读取。pageIndex 枚举包括隐藏正文在内的嵌套 Page，pageCoverage.nextOffset 用 pageOffset 继续。每张裁切图附 elementIndex，稳定 nodeId 不随裁切变化；长索引用 elementOffset 继续。

```json
{ "projectId": "项目ID", "pageId": "资源ID" }
```

## 沿同一张图细读

以下查询都使用首读返回的 snapshotId 与资源 pageId：

- `board_read({snapshotId,mode:"tile",tileIds:["T1"]})` 只返回指定裁切图。
- `board_read({snapshotId,mode:"region",tileId:"T1",pointPx:{x:420,y:300}})` 用图像像素找候选元素并截图；rectPx 可替代 pointPx。候选可能有重叠对象，按 nodeId 再查。像素输入始终对应原裁切图分辨率；scale 只提高细节截图分辨率。超过单图尺寸时缩小 region。
- `board_read({snapshotId,mode:"element",nodeId:"对象ID",detail:"both",tileId:"T1"})` 验证元素出现在 T1 中，返回整个对象外框的截图与完整原始节点；大对象图像分页。只看 T1 内的局部用 mode:region。detail:source 只读源。
- `page_read({snapshotId,blockIds:["Page节点ID"],rendered:false,response:"source"})` 读取该 Page 完整正文和原始组件数据，包含其外框之外的内容。截图保持 Page 当前可见范围；原始正文不受外框裁切。省略 blockIds 可读整个保存资源。
- `board_read({snapshotId,mode:"source"})` 返回 Board 格式化原始子树、layout、surfaceViews、父路径与外部连接引用；画笔保留 points、extent、颜色和粗细，组件保留原始 props。

```json
{
  "projectId": "项目ID",
  "pageId": "资源ID",
  "snapshotId": "首读返回的ID",
  "mode": "element",
  "nodeId": "Page节点ID",
  "tileId": "T1",
  "detail": "both"
}
```

快照将原始数据、组件精确引用与实际渲染状态固定在同一次捕获中，有效期 30 分钟；过期返回 SNAPSHOT_EXPIRED，重新首读。currentSourceChanged 标记保存资源是否在捕获后变化，旧图与旧数据仍对应。origin:saved 表示按已保存源渲染，provided-draft 表示显式 draftDocument；默认不会读取正在编辑的 App 实时状态。可显式 state.cameras/pageScrolls 指定嵌套视口与滚动。warnings 报告不可用组件；位图、canvas 与视频帧保留捕获时分辨率，矢量和文字支持重新放大。读取不保存正文。局部结果不能覆盖整页；编辑前重新 page_read 完整当前源，使用当前 hash/revision。

## 普通 Page 与交互

普通 Page 内容分析和编辑使用 structured；format:markdown 用于正文与组件数据。长页先 detail:outline，再用 blockIds 选择局部，纯源用 rendered:false。源超过 256 KiB 的页面，不指定 detail、blockIds 或 out 的读取只返回大纲窗口（仍带整页的 hash 与 revision，可直接作为 page_apply 的基线；大纲每项有 id、type、title 与层级）：前 100 个顶层块及其子项、`blockCount`、`nextOffset`，以及说明省略了 document、markdown 与 computed 的 `omitted`。用 `offset:nextOffset`（可加 `limit`，最多 1000）继续看大纲，用 blockIds 读需要的块；确实需要整页时传 `detail:"full"`，本机连接也可以用 out 写入文件。结构化读取只为计算组件结果而渲染这些组件本身，所以页面再长也不受截图高度限制。

颜色、布局、遮挡用 page_read 的 view:image，指定 viewport/theme 并保留 hash、组件引用和状态。默认 `capture:"full"` 覆盖整页或所选 blockIds 的完整高度，viewport（默认 1000×900）的 height 只决定初始布局；高于 16000 px 时报错，PNG 超过 8 MiB 时同样报错，这两种情况都改用更少的 blockIds 分几次截，并用 out 把图片写进文件。要看清文字时每段控制在约 3000 px 高，过高的图交给模型查看时会被缩小到难以辨认。截图只看到首屏时，先核对返回的 image.height，确认运行时是否已更新；交互用 view:html，先读真实可访问性快照，再按控件实际名称操作。actions 可重放 hover、click、fill、select、check、uncheck、drag；控件不存在或重名会报错。不同状态对比保持同一宽高和源版本。正式宿主交互验收遵循当前任务的官方浏览器/电脑操控规则，自动化读图与读取 HTML 源码不能代替操作验收。

### 固定视口与实际布局测量

检查一屏能看到什么时，用 `page_read({projectId,pageId,view:"image",capture:"viewport",viewport:{width:1440,height:900},scrollToBlockId:"目标块ID",inspect:{layout:true,blockIds:["图ID","说明ID"]}})`。`capture:"viewport"` 保持窗口尺寸，PNG 不扩高；`scrollToBlockId` 在完整页面里滚动到该块，不会自动展开隐藏的步骤。先查实际 inputSchema；旧运行时不支持时明确报告，不能用长截图冒充一屏截图。

`inspect.blockIds` 只选择测量对象，不删除周围内容。顶层 `blockIds` 会抽出局部页面、可能改变布局；要测正式页面中的位置，不传顶层 `blockIds`。所有参数只用于读取，不保存页面。

结果中的 `capture` 给出 mode、requestedViewport、renderedViewport、expanded。`layout` 在全文截图扩高之前按请求视口测量：`rect` 和 `visibleRect` 是相对视口的 CSS 像素坐标；`visibleFraction` 是矩形经视口与祖先裁切后的面积比例；`viewportHeightRatio` 是块高/视口高；`overflow` 给出横纵溢出、CSS overflow 模式及 client/scroll 尺寸。可滚动表格有溢出不等于错误。DOM 没挂载的块返回 `status:"not-rendered"`，包括未展开步骤；默认测前 200 个 DOM 块并返回 total/truncated，更多对象显式指定至多 100 个 ID。

这些是测量，不是质量评分；兄弟元素遮挡、非矩形遮罩、iframe 内部、位图文字和 canvas 内容不在覆盖范围。Agent 根据自己的布局意图解释结果，再用原有编辑工具调整、以相同视口和定位复测。用 out 时，回执保留 capture/layout，完整元数据也在 metadataPath 指向的 `.read.json`。

rendered 读取生成文件与 .read.json 记录来源和状态。本机连接传 `out:"/绝对路径/文件"` 时，结构化源（JSON 或 markdown）、image 的 PNG 或 html 写入该文件，回执只含 out（path、bytes、sha256）与 hash、revision（页面有绑定块时还带 datasetBases，键就是共享数据 id，可直接用于 dataset_read），不再把整页或图片放回对话；已有文件需加 overwrite:true。结构化源文件含 document、outline、computed（rendered:false 时为空），以及绑定块的 bindings（解析后的 props）与 datasetBases，内容不受 response 影响；共享数据本身另用 `dataset_read` 的 out 写出。draft:true 只在临时预览编辑，不写入正式 Page；computed.props 是预览数据。声明 manifest.reader=readData 的组件可返回同步派生数据，保留原始 props，按稳定 ID 核对 computed.data。渲染需要运行时浏览器与组件编译能力；缺失时明确报告，JSON 可读不能证明视觉通过。

## 页面之间的引用

`page_read({projectId,pageId,references:"to"})` 在读取结果里加上 references：to 列出引用这一页的页面（反向链接），from 列出这一页引用的页面，`references:"both"` 两者都给。每一项有 projectId、pageId、title、blockId（引用所在页面上的块，可直接作为 page_read 的 blockIds）、blockIds（引用指向的块）、kind 和 snippet。snippet 是引用所在段落或标题的文字（含行内日期等组件的值），超过 200 字时截取引用前后的部分；需要整段时用 blockId 读取引用页。kind 为 link 时是正文里的页面链接（包括组件里的文字和步骤），database 是数据库的页面列（数据存在共享数据里的数据库同样计入；关联列保存的是记录 id，不算页面引用），component 是自定义组件声明的页面字段。每个方向最多列出 200 条，total 给出全部引用数，pages 给出不重复的页面数（例如“3 个页面引用了这一页”用 pages.to）。只要引用时配合 `response:"receipt"`：回执保留 references，不带整页正文。已删除的页面不出现在 to 中；from 里已删除或不存在的目标标为 missing。绑定项目的连接只看到本项目内的引用。命令行用 `showai pages read PAGE --project PROJECT --references both --json`。

```json
{ "projectId": "项目ID", "pageId": "页面ID", "references": "to", "response": "receipt" }
```
