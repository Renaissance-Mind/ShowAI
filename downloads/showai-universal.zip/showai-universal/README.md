# ShowAI Universal

Install the plugin in a compatible host, or load the six folders under `skills/` in an Agent Skills client. This package supplies the six Skills. Select an existing ShowAI MCP connection in your host, or ask “Help me connect ShowAI” to set one up.

在支持插件的宿主中导入本包，或在支持 Agent Skills 的客户端加载 `skills/` 下的六个目录。本包提供六个 Skills。请在宿主中选择已有的 ShowAI MCP 连接。首次连接时，可以对 Agent 说「帮我连接 ShowAI」。

[Connection guide / 接入向导](skills/use-showai/references/connect-mcp.md)
